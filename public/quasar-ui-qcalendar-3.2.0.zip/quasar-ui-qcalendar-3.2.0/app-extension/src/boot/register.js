import Vue from 'vue'
import VuePlugin from '@quasar/quasar-ui-qcalendar'

Vue.use(VuePlugin)
