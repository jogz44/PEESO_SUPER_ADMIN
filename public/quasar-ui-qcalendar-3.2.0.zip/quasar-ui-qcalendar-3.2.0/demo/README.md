# quasar-ui-qcalendar Demo
In order to build the demo, you must first build the UI.
Go to the `ui` folder and `yarn build`. This will create the JSON API in the `ui/dist` folder that the demo needs in order to be built.

# Building
To build the demo, type `quasar dev`.