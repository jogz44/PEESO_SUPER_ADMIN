export default {
  titlebarHeight: 0,
  toc: []
}
