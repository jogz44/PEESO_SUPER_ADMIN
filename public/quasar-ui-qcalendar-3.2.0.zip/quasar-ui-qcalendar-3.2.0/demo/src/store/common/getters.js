export const titlebarHeight = (state) => state.titlebarHeight
export const toc = (state) => state.toc
