export const currentStyleName = (state) => state.currentStyleName
export const style = (state) => state.style
export const hints = (state) => state.hints
