<template>
  <div class="q-markdown">
    <q-markdown>
Customization - this page will include examples, like working with themes
    </q-markdown>
  </div>
</template>

<script>
export default {
  data () {
    return {
      //
    }
  }
}
</script>

<style>

</style>
