<template>
  <q-page padding>
    Pick an item on the left to see the example and code.
  </q-page>
</template>

<script>
export default {
  // name: 'PageName',
}
</script>

<style>
</style>
